#!/bin/bash 
 
if [[ $1 == "-help" ]]; then 	 

echo "SCRIPT DE BACKUP"

echo "Uso: [script][origen][destino]. Ejemplo: /opt/scripts/backup_full.sh /var/logs /backup_dir"

echo "Este script permite enviar que se necesita hacer un backup y donde se desea almacenar el mismo." 

echo "El archivo se creará con el nombre RUTA_bkp_FECHA.tar.gz Siendo RUTA la segunda parte del path y FECHA el timestamp de la fecha en la que se realiza el backup" 
	exit 0 
 
elif [[ $# -ne 2 ]]; then 
	echo "El script espera recibir 2 parámetros, la ruta de origen y la ruta de destino."
	exit 1 
fi 
 
if [[ ! -d "$1" ]]; then 
	echo "El origen $1 no existe"

	exit 1 
elif [[ ! -d "$2" ]]; then 
	echo "El destino $2 no existe" 
	exit 1 

fi
 

 
FECHA=$(date +%Y%m%d) 
 
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz 
 echo "$2/$BACKUP"
tar -czf "$2/$BACKUP" -C "$1" .   

 
if [[ $? == 0 ]]; then 
	echo "El backup se creó correctamente!!"
	exit 0
else 
	echo "Ha ocurrido un error en el proceso y el backup no pudo ser creado."
	exit 1 
fi
